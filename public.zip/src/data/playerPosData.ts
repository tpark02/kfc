export const playerPosData = [
    { code: 'gk', name: 'Goalkeeper' },
    { code: 'cb', name: 'Center Back' },
    { code: 'lb', name: 'Left Back' },
    { code: 'rb', name: 'Right Back' },
    { code: 'cdm', name: 'Center Defensive Midfielder' },
    { code: 'cm', name: 'Center Midfielder' },
    { code: 'cam', name: 'Center Attacking Midfielder' },
    { code: 'lm', name: 'Left Midfielder' },
    { code: 'rm', name: 'Right Midfielder' },
    { code: 'lw', name: 'Left Winger' },
    { code: 'rw', name: 'Right Winger' },
    { code: 'st', name: 'Striker' }
  ];
  