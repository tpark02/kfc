
export type CountryList = {
   country: Country
  }[];

export type Country = {
    name: string;
    code: string;
  };