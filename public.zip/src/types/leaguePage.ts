import { League } from "./league";

export type LeaguePage = {
    content: League[]; // 팀 정보 배열
}