import { Team } from "./team";

export type TeamPage = {
    content: Team[]; // 팀 정보 배열
}