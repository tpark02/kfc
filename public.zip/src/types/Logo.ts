export type Logo ={
    id: number; 
    logoImg: string
}