 
 export type LeagueList = {
    league: League
   }[];

 export type League = {
  id: number;
     name: string;
     url: string;
   };