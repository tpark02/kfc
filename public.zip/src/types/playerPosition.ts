
export type PlayerPosList = {
    playerPos: PlayerPos
   }[];
 
 export type PlayerPos = {
     name: string;
     code: string;
   };