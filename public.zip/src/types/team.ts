 
 export type Team = {
  id: number;
  name: string;
  url: string;
};

export const totalNumberOfPlayers = 17;