// import LeagueScheduleViewer from "../../components/LeagueSimulator/LeagueScheduleViewer";
// import LeagueMyTeam from "../../components/LeagueSimulator/LeagueMyTeam";
// import LeagueOpponentTeam from "../../components/LeagueSimulator/LeagueOpponentTeam";

import SeasonLobby from "./SeasonLobby";

const Season = () => {
  return (
    <div>
      {/* <LeagueMyTeam />
      <LeagueScheduleViewer />
      <LeagueOpponentTeam /> */}

      {/* <JoinSeasonButton seasonId={1} /> */}
      {/* <ChampionsBracket seasonId={1} /> */}
      <SeasonLobby />
    </div>
  );
};

export default Season;
